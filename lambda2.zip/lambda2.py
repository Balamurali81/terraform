import json
print('*********************Loading function****************')

def bala(event, context):
    x = "Lambda Deployment using enterprise pipeline"
    return x

